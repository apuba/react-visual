import React from 'react'

export default Code => {
  return (
    <div>
      源代码预览区
    </div>
  )
}
