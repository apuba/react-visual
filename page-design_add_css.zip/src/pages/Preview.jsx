import React, { Component } from 'react'

export default class Preview extends Component {
  render() {
    return (
      <div>
        预览页面
      </div>
    )
  }
}
