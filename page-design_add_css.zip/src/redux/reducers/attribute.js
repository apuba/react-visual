// 用来存储当前模块下的数据
const state = {
  list:[],
  count:0
}

export default state