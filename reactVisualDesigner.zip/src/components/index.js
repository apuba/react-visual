/* 所有可用组件集合
 * @Author: houxingzhang
 * @Date: 2019-08-27 14:10:41
 * @Last Modified by: houxingzhang
 * @Last Modified time: 2019-09-05 16:57:34
 */

import RJSelect from './RJSelect'
import * as allComponents from 'antd'
Object.assign(allComponents, {
  RJSelect
})
export default allComponents
