/*
 * @Description: 
 * @Author: 侯兴章
 * @Date: 2019-09-17 15:17:03
 * @LastEditors: 侯兴章
 * @LastEditTime: 2019-09-17 15:17:03
 */
import { createStore } from 'redux';
import rootReducer from './reducers';

export default createStore(rootReducer);
