/*
 * @Description: 
 * @Author: 侯兴章
 * @Date: 2019-09-17 15:17:03
 * @LastEditors: 侯兴章
 * @LastEditTime: 2019-09-17 15:17:03
 */
// 用来存储当前模块下的数据
const state = {
  list: [],
  count: 0
};

export default state;
