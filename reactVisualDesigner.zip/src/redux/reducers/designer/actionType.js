/*
 * @Description: 
 * @Author: 侯兴章
 * @Date: 2019-09-17 15:17:03
 * @LastEditors: 侯兴章
 * @LastEditTime: 2019-09-17 15:17:03
 */
export const UPDATE_DYNAMICCOMPONENT_LIST = 'UPDATE_DYNAMICCOMPONENT_LIST'; // 更新动态组件
export const UPDATE_TOGGLE = 'UPDATE_TOGGLE'; // 更新开关
export const UPDATE_EDITCOMPONENTID = 'UPDATE_EDITCOMPONENTID'; // 当前编辑的组件
export const UPDATE_GRAGGABLE = 'UPDATE_GRAGGABLE'; // 更新拖拽对象
export const UPDATE_TIMESPAN = 'UPDATE_TIMESPAN'; // 更新时间戳
export const UPDATE_BASE_STATE = 'UPDATE_BASE_STATE'; // 简单更新一个状态
export const UPDATE_DATASOURCE = 'UPDATE_DATASOURCE'; // 更新数据源
export const UPDATE_DATASOURCE_STATIC = 'UPDATE_DATASOURCE_STATIC'; // 更新静态数据源
