import { combineReducers } from 'redux';

import designer from './designer';
import attribute from './attribute';

export default combineReducers({ designer, attribute });
