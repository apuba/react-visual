
export const getStaticDataSource = store => store && store.dataSource ? store.dataSource.static : {}
