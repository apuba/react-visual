/* 生成的JSX代码预览
 * @Author: houxingzhang
 * @Date: 2019-09-05 17:16:54
 * @Last Modified by: houxingzhang
 * @Last Modified time: 2019-09-07 17:34:46
 */
import React from 'react'

export default props => {
  return (
    <div>
      <textarea className='page_designer_code' value={props.code} readOnly>
        源代码预览区
      </textarea>
    </div>
  )
}
