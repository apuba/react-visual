import React, { Component } from 'react'

export default class Code extends Component {
  render () {
    return (
      <div>
        源代码预览区
      </div>
    )
  }
}
