/* 所有可用组件集合
 * @Author: houxingzhang 
 * @Date: 2019-08-27 14:10:41 
 * @Last Modified by: houxingzhang
 * @Last Modified time: 2019-08-28 11:28:28
 */

import HelloWorld from './HelloWorld'
var allComponents = require('antd')

Object.assign(allComponents, {
  HelloWorld
})

export default allComponents
